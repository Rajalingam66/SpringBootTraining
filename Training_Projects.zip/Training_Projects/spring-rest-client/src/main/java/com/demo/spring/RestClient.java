package com.demo.spring;

import org.apache.commons.codec.binary.Base64;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

public class RestClient {

	public static void main(String[] args) {
		RestTemplate template = new RestTemplate();
		String userDetails = "arun:welcome1";
		String encryptedCred = new String(Base64.encodeBase64(userDetails.getBytes()));
		System.out.println(encryptedCred);

		HttpHeaders headers = new HttpHeaders();
		headers.set("Accept", "application/json");
		headers.set("Authorization", "Basic " + encryptedCred);

		HttpEntity reqEntity = new HttpEntity<>(headers);

		ResponseEntity response = template.exchange("http://localhost:8080/spring-restful/emp?id=1009", HttpMethod.GET,
				reqEntity, String.class);

		System.out.println(response.getBody());

	}

}
