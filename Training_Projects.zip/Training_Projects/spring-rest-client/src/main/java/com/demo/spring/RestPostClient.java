package com.demo.spring;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

public class RestPostClient {

	public static void main(String[] args) {
		RestTemplate template = new RestTemplate();
		
		String empJson ="{\"empId\": 1502,\"name\": \"Sunil\",\"city\": \"Bangalore\",\"salary\": \"80000\"}";
		
		
		
		

		HttpHeaders headers = new HttpHeaders();
		headers.set("Accept", MediaType.TEXT_PLAIN_VALUE);
		headers.set("Content-Type", "application/json");

		HttpEntity reqEntity = new HttpEntity<>(empJson,headers);

		ResponseEntity response = template.exchange("http://localhost:8085/employee/empSave", HttpMethod.POST,
				reqEntity, String.class);

		System.out.println(response.getBody());

	}

}
