package com.demo.spring;

import java.util.HashMap;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.demo.spring.entity.Employee;

@RestController
public class EmpRestController {

	static HashMap<Integer, Employee> empDb = new HashMap<>();
	static {
		empDb.put(1000, new Employee(1000, "Scott", "Hyderabad", 75000));
		empDb.put(1001, new Employee(1001, "Raja", "Chennai", 85000));
		empDb.put(1002, new Employee(1002, "Rahul", "Bangalore", 65000));
		empDb.put(1003, new Employee(1003, "Rohit", "Mumbai", 45000));
		empDb.put(1004, new Employee(1004, "Raina", "Gujarat", 55000));
		empDb.put(1005, new Employee(1005, "Hardik", "Haryana", 35000));
		empDb.put(1006, new Employee(1006, "Dhoni", "Jarkand", 15000));
		empDb.put(1007, new Employee(1007, "Umesh", "Indore", 25000));
		empDb.put(1008, new Employee(1008, "Vivek", "Simla", 105000));
		empDb.put(1009, new Employee(1009, "Sudip", "Ooty", 95000));
		empDb.put(1010, new Employee(1010, "Praveen", "Coimbatore", 75000));

	}

	@RequestMapping(path = "/info", method = RequestMethod.GET)
	public String info() {
		return "This is Simple RESTful Service";
	}

	@RequestMapping(path = "/greet/{name}", method = RequestMethod.GET)
	public String info(@PathVariable("name") String name) {
		return "Welcome " + name;
	}

	@RequestMapping(path = "/emp", method = RequestMethod.GET,produces={MediaType.APPLICATION_XML_VALUE,MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity getEmployee(@RequestParam("id") int id) {
		if (empDb.containsKey(id)) {
			Employee emp= empDb.get(id);
			return ResponseEntity.ok(emp);
		} else {
			return ResponseEntity.ok("Employee does not exists..");
		}
	}

}
