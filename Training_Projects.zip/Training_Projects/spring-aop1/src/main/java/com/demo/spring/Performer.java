package com.demo.spring;

public interface Performer {

	public void perform();
}
