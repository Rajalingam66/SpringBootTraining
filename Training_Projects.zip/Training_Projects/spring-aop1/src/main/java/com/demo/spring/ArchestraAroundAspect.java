package com.demo.spring;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
@Aspect
@Order(value=2)
public class ArchestraAroundAspect {

	@Pointcut("execution(* com.demo.spring.Singer.perform())")
	private void pcut() {

	}

	@Around("pcut()")
	public void invoke(ProceedingJoinPoint pjp) throws Throwable {
		System.out.println("Musician start playing...");
		pjp.proceed();
		System.out.println("Musician stop playing...");

	}
}
