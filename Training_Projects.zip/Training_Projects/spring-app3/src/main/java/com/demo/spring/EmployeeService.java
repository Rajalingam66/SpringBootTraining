package com.demo.spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.demo.spring.entity.Employee;

@Service
public class EmployeeService {

	@Autowired
	@Qualifier("jdbc")
	EmployeeDao dao;

	public String registerEmployee(int id, String name, String city, double salary) {
		String response = dao.save(new Employee(id, name, city, salary));
		return response;
	}

}
