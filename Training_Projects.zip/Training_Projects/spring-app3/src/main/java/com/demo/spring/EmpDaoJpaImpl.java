package com.demo.spring;

import org.springframework.stereotype.Repository;

import com.demo.spring.entity.Employee;

@Repository("jpa")
public class EmpDaoJpaImpl implements EmployeeDao {

	@Override
	public String save(Employee emp) {

		return "JPA: Emp saved with ID " + emp.getEmpId();
	}

}
