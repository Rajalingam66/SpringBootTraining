package com.demo.spring;

import org.springframework.context.annotation.*;

@Configuration
@ComponentScan(basePackages="com.demo.spring")
public class AppConfig {

}
