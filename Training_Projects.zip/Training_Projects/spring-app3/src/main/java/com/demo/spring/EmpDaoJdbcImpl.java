package com.demo.spring;

import org.springframework.stereotype.Repository;

import com.demo.spring.entity.Employee;

@Repository("jdbc")
public class EmpDaoJdbcImpl implements EmployeeDao {

	@Override
	public String save(Employee emp) {

		return "JDBC: Emp saved with ID " + emp.getEmpId();
	}

}
