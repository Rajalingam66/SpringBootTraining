package com.demo.spring;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.demo.spring.entity.Employee;

@Component("decorate")
public class DecorateWriter implements Writer {

	@Override
	public String write(String str) {

		return "Welcome " + str;
	}

}
