package com.demo.spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.demo.spring.entity.Employee;

@Service
public class WriterService {

	@Autowired
	@Qualifier("text")
	Writer writer;
	
	public void print(String str)
	{
		System.out.println(writer.write(str));
	}

}
