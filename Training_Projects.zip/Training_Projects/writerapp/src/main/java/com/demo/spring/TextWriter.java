package com.demo.spring;

import org.springframework.stereotype.Component;

@Component("text")
public class TextWriter implements Writer {
	public String write(String str) {
		
		return str;
	}

}
