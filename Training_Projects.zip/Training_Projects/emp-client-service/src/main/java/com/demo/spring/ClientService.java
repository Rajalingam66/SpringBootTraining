package com.demo.spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service
public class ClientService {

	@Autowired
	RestTemplate template;

	@HystrixCommand(fallbackMethod = "getEmployeeFallback")
	public ResponseEntity getEmployee(int empId) {

		HttpHeaders headers = new HttpHeaders();
		headers.set("Accept", "application/xml");

		HttpEntity reqEntity = new HttpEntity<>(headers);

		ResponseEntity response = template.exchange("http://boot-app1/employee/emp?id=" + empId, HttpMethod.GET,
				reqEntity, String.class);

		return response;

	}

	public ResponseEntity getEmployeeFallback(int empId) {

		System.out.println("++++++++++++++++++++++++++++Inside fallback method.....");
		return ResponseEntity.ok("Service is unavailable");

	}

}
