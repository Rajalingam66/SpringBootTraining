package com.demo.spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/emp")
public class EmpClientService {

	@Autowired
	ClientService service;

	@RequestMapping(path = "/get/{id}", produces = { MediaType.TEXT_PLAIN_VALUE})
	public ResponseEntity fetch(@PathVariable("id") int empId) {
		return service.getEmployee(empId);

	}

}
