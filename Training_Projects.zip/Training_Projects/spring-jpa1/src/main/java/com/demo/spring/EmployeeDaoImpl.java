package com.demo.spring;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.demo.spring.entity.Employee;

@Repository
@Transactional
public class EmployeeDaoImpl implements EmployeeDao {

	@PersistenceContext
	EntityManager entityManager;

	@Override
	public String save(Employee emp) {
		entityManager.persist(emp);

		return "Emp Saved";
	}

	@Override
	public String delete(int empId) {
		entityManager.remove(entityManager.find(Employee.class, empId));
		return null;
	}

	@Override
	public Employee getById(int empId) {
		Employee emp = entityManager.find(Employee.class, empId);
		return emp;
	}

	@Override
	public List<Employee> getAll() {
		Query query = entityManager.createQuery("select e from Employee e");
		List<Employee> employees = query.getResultList();
		return employees;
	}

	@Override
	public String saveEmployees(List<Employee> employees) {
		for (Employee emp : employees) {
			entityManager.persist(emp);
		}
		return "Employee details are saved";
	}

}
