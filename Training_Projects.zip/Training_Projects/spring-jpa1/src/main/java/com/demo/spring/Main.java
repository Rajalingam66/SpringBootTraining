package com.demo.spring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.demo.spring.entity.Employee;

public class Main {

	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		EmployeeDao dao = (EmployeeDao) context.getBean("employeeDaoImpl");
		//dao.delete(500);
		// Employee emp = dao.getById(600);

		for (Employee emp : dao.getAll()) {
			System.out.println(emp.toString());
		}

		// System.out.println(dao.save(new Employee(600, "Davis", "Chennai",
		// 80000)));

	}

}
