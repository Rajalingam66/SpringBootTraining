package com.demo.spring;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.demo.spring.entity.User;

@Controller
public class LoginController {

	@PersistenceContext
	EntityManager entityManager;

	@RequestMapping(path = "/login", method = RequestMethod.GET)
	public String getLoginPage() {
		return "login";
	}

	@RequestMapping(path = "/login", method = RequestMethod.POST)
	public ModelAndView processLogin(@RequestParam("username") String userName,
			@RequestParam("password") String password) {

		ModelAndView modelView = new ModelAndView();

		User user = entityManager.find(User.class, userName);

		if (user != null) {
			if (user.getPassword().equals(password)) {
				modelView.setViewName("success");
				User model = new User();
				model.setUsername(userName);
				model.setMessage("Success");
				modelView.addObject("user", model);
			} else {
				modelView.setViewName("failure");
				modelView.addObject("user", userName);
			}
		} else {
			modelView.setViewName("login");
		}

		return modelView;

	}

}
