package com.demo.spring;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.demo.spring.entity.Employee;

@Controller
public class TestController {

	@RequestMapping(path = "/demo", method = RequestMethod.GET)
	public String getPage() {
		return "test";
	}

	@RequestMapping(path = "/getjson", method = RequestMethod.GET)
	public @ResponseBody List<Employee> getJson() {

		List<Employee> empList = new ArrayList<Employee>();
		Employee emp1 = new Employee(500, "Suresh", "Bangalore", 90000);
		Employee emp2 = new Employee(400, "Rajesh", "Cochin", 60000);
		Employee emp3 = new Employee(700, "Raj", "Chennai", 50000);
		empList.add(emp1);
		empList.add(emp2);
		empList.add(emp3);

		return empList;
	}

}
