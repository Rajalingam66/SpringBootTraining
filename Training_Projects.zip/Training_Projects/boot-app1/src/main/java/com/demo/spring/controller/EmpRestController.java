package com.demo.spring.controller;

import java.util.HashMap;

import javax.servlet.ServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.demo.repository.EmployeeRepository;
import com.demo.spring.entity.Employee;

@RestController
public class EmpRestController {

	@Autowired
	EmployeeRepository repository;

	@RequestMapping(path = "/info1", method = RequestMethod.GET, produces = { MediaType.TEXT_PLAIN_VALUE })
	public String info() {
		return "This is Simple RESTful Service";
	}

	@RequestMapping(path = "/greet/{name}", method = RequestMethod.GET)
	public String info(@PathVariable("name") String name) {
		return "Welcome " + name;
	}

	@RequestMapping(path = "/emp", method = RequestMethod.GET, produces = { MediaType.APPLICATION_XML_VALUE,
			MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity getEmployee(@RequestParam("id") int id, ServletRequest req) {

		System.out.println(
				"++++++++++++++******************Request Served by : " + req.getLocalAddr() + ":" + req.getLocalPort());
		Employee emp = repository.findOne(id);

		if (emp != null) {
			return ResponseEntity.ok(emp);
		} else {
			return ResponseEntity.ok("Employee does not exists..");
		}
	}

	@RequestMapping(path = "/empSave", method = RequestMethod.POST, consumes = { MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity saveEmployee(@RequestBody Employee emp) {

		Employee newEmp = repository.save(emp);

		if (newEmp.getEmpId() == emp.getEmpId()) {
			return ResponseEntity.ok("Employee saved successfully...");
		} else {
			return ResponseEntity.ok("Employee can not be saved..");
		}
	}

}
