package com.demo.spring;

import com.demo.spring.entity.Employee;

public class EmpDaoJpaImpl implements EmployeeDao {

	@Override
	public String save(Employee emp) {

		return "JPA: Emp saved with ID " + emp.getEmpId();
	}

}
