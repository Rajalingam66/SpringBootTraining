package com.demo.spring;

import com.demo.spring.entity.Employee;

public interface EmployeeDao {
	
	public String save(Employee emp);

}
