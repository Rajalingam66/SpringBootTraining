package com.demo.spring;

import com.demo.spring.entity.Employee;

public class EmpDaoJdbcImpl implements EmployeeDao {

	@Override
	public String save(Employee emp) {

		return "JDBC: Emp saved with ID " + emp.getEmpId();
	}

}
