package com.demo.spring;

import com.demo.spring.entity.Employee;

public class EmployeeService {
	EmployeeDao dao;
	
	public void setDao(EmployeeDao dao) {
		this.dao = dao;
	}

	public String registerEmployee(int id, String name, String city, double salary) {
		String response = dao.save(new Employee(id, name, city, salary));
		return response;
	}

}
