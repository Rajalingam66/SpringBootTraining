package com.demo.spring;

import java.util.List;

import com.demo.spring.entity.Employee;

public interface EmployeeDao {

	public String save(Employee emp);

	public String delete(int empId);

	public Employee getById(int empId);

	public List<Employee> getAll();

	public String saveEmployees(List<Employee> employees);

}
