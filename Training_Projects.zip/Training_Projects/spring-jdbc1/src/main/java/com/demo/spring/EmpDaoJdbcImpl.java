package com.demo.spring;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.demo.spring.entity.Employee;

@Repository
public class EmpDaoJdbcImpl implements EmployeeDao {

	@Autowired
	JdbcTemplate template;

	@Override
	public String save(Employee emp) {

		int count = template.update(new PreparedStatementCreator() {

			@Override
			public PreparedStatement createPreparedStatement(Connection conn) throws SQLException {
				PreparedStatement pst = conn
						.prepareStatement("insert into emp(empno,name,address,salary) values(?,?,?,?)");
				pst.setInt(1, emp.getEmpId());
				pst.setString(2, emp.getName());
				pst.setString(3, emp.getCity());
				pst.setDouble(4, emp.getSalary());

				return pst;
			}
		});
		if (count > 0) {
			return "Emp saved with ID " + emp.getEmpId();
		} else {
			return "Emp details are not saved!!";
		}
	}

	@Override
	public String delete(int empId) {
		int count = template.update(new PreparedStatementCreator() {

			@Override
			public PreparedStatement createPreparedStatement(Connection conn) throws SQLException {
				PreparedStatement pst = conn.prepareStatement("delete from emp where empno=" + empId);
				return pst;
			}
		});

		if (count > 0) {
			return "Employee with Id " + empId + " is deleted successfully..";
		} else {
			return "Employee id : " + empId + " is not found in DB";
		}

	}

	@Override
	public Employee getById(int empId) {
		Employee emp = template.queryForObject("select * from emp where empno=" + empId, new RowMapper<Employee>() {

			@Override
			public Employee mapRow(ResultSet resultSet, int indx) throws SQLException {

				return new Employee(resultSet.getInt("empno"), resultSet.getString("name"),
						resultSet.getString("address"), resultSet.getDouble("salary"));
			}

		});
		return emp;
	}

	@Override
	public List<Employee> getAll() {

		List<Employee> empList = template.query("select * from emp", new RowMapper<Employee>() {

			@Override
			public Employee mapRow(ResultSet resultSet, int indx) throws SQLException {

				return new Employee(resultSet.getInt("empno"), resultSet.getString("name"),
						resultSet.getString("address"), resultSet.getDouble("salary"));
			}

		});
		;
		return empList;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public String saveEmployees(List<Employee> employees) {
		for (Employee emp : employees) {
			save(emp);
		}
		return "Saved successfully";
	}

}
