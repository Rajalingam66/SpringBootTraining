package com.demo.spring;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.demo.spring.entity.Employee;

public class Main {

	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		
		EmployeeDao empDao = (EmployeeDao) context.getBean("empDaoJdbcImpl");
		// String insertStatus = empDao.save(new Employee(600, "Davis","Chennai", 80000));
		/*
		 * Employee emp = empDao.getById(500); List<Employee> empList =
		 * empDao.getAll();
		 */
		//String deleteStatus = empDao.delete(600);
		List<Employee> empList = new ArrayList<Employee>();
		Employee emp1 = new Employee(500, "Suresh", "Bangalore", 90000);
		Employee emp2 = new Employee(400, "Rajesh", "Cochin", 60000);
		Employee emp3 = new Employee(700, "Raj", "Chennai", 50000);
		empList.add(emp1);
		empList.add(emp2);
		empList.add(emp3);
		String response = empDao.saveEmployees(empList);
		System.out.println(response);
		/*
		 * System.out.println("Get By Id Result : " + emp.toString());
		 * System.out.println("List of employees"); for (Employee employee :
		 * empList) { System.out.println(employee.toString()); }
		 */

		

	}

}
